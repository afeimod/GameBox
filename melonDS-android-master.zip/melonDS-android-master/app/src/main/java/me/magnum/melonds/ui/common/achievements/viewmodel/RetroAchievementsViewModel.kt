package me.magnum.melonds.ui.common.achievements.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import me.magnum.melonds.domain.model.rom.Rom
import me.magnum.melonds.domain.model.retroachievements.RAUserAchievement
import me.magnum.melonds.domain.repositories.RetroAchievementsRepository
import me.magnum.melonds.domain.repositories.SettingsRepository
import me.magnum.melonds.ui.romdetails.model.AchievementBucketUiModel
import me.magnum.melonds.ui.romdetails.model.AchievementSetUiModel
import me.magnum.melonds.ui.romdetails.model.RomAchievementsSummary
import me.magnum.melonds.ui.romdetails.model.RomRetroAchievementsUiState
import me.magnum.rcheevosapi.exception.UserTokenExpiredException
import me.magnum.rcheevosapi.model.RAAchievement
import me.magnum.rcheevosapi.model.RAUserAuth

abstract class RetroAchievementsViewModel (
    private val retroAchievementsRepository: RetroAchievementsRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow<RomRetroAchievementsUiState>(RomRetroAchievementsUiState.Loading)
    val uiState by lazy {
        loadAchievements()
        _uiState.asStateFlow()
    }

    private val _viewAchievementEvent = MutableSharedFlow<String>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val viewAchievementEvent = _viewAchievementEvent.asSharedFlow()

    private var achievementLoadJob: Job? = null

    protected abstract fun getRom(): Rom

    protected abstract suspend fun buildAchievementBuckets(achievements: List<RAUserAchievement>): List<AchievementBucketUiModel>

    private fun loadAchievements() {
        achievementLoadJob?.cancel()
        achievementLoadJob = viewModelScope.launch {
            val userAuth = retroAchievementsRepository.getUserAuthentication()
            _uiState.value = when (userAuth) {
                is RAUserAuth.Authenticated -> {
                    val forHardcoreMode = settingsRepository.isRetroAchievementsHardcoreEnabled()
                    retroAchievementsRepository.getUserGameData(getRom().retroAchievementsHash, forHardcoreMode).fold(
                        onSuccess = { userGameData ->
                            val sets = userGameData?.sets?.map { set ->
                                AchievementSetUiModel(
                                    setId = set.id.id,
                                    setTitle = set.title,
                                    setType = set.type,
                                    setIcon = set.iconUrl,
                                    setSummary = buildAchievementsSummary(forHardcoreMode, set.achievements),
                                    buckets = buildAchievementBuckets(set.achievements),
                                )
                            }
                            RomRetroAchievementsUiState.Ready(sets.orEmpty())
                        },
                        onFailure = {
                            ensureActive()
                            if (it is UserTokenExpiredException) {
                                val userAuth = retroAchievementsRepository.getUserAuthentication()
                                val existingUsername = (userAuth as? RAUserAuth.AuthenticationExpired)?.username
                                RomRetroAchievementsUiState.LoggedOut(existingUsername)
                            } else {
                                RomRetroAchievementsUiState.AchievementLoadError
                            }
                        },
                    )
                }
                is RAUserAuth.AuthenticationExpired -> RomRetroAchievementsUiState.LoggedOut(userAuth.username)
                null -> RomRetroAchievementsUiState.LoggedOut(null)
            }
        }
    }

    fun login(username: String, password: String) {
        _uiState.value = RomRetroAchievementsUiState.Loading
        viewModelScope.launch {
            val result = retroAchievementsRepository.login(username, password)
            if (result.isSuccess) {
                loadAchievements()
            } else {
                _uiState.value = RomRetroAchievementsUiState.LoginError
            }
        }
    }

    fun retryLoadAchievements() {
        _uiState.value = RomRetroAchievementsUiState.Loading
        loadAchievements()
    }

    fun viewAchievement(achievement: RAAchievement) {
        val achievementUrl = "https://retroachievements.org/achievement/${achievement.id}"
        _viewAchievementEvent.tryEmit(achievementUrl)
    }

    private fun buildAchievementsSummary(forHardcoreMode: Boolean, userAchievements: List<RAUserAchievement>): RomAchievementsSummary {
        return RomAchievementsSummary(
            forHardcoreMode = forHardcoreMode,
            totalAchievements = userAchievements.size,
            completedAchievements = userAchievements.count { it.isUnlocked },
            totalPoints = userAchievements.sumOf { it.userPointsWorth() },
        )
    }
}